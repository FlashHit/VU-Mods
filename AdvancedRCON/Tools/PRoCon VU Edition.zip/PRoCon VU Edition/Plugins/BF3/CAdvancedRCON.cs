using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading;
using System.Timers;

using PRoCon.Core;
using PRoCon.Core.Plugin;
using PRoCon.Core.Plugin.Commands;
using PRoCon.Core.Players;
using PRoCon.Core.Players.Items;
using PRoCon.Core.TextChatModeration;
using PRoCon.Core.Battlemap;
using PRoCon.Core.Maps;
using PRoCon.Core.HttpServer;

namespace PRoConEvents {
	
	public class CAdvancedRCON : PRoConPluginAPI, IPRoConPluginInterface {
		
		public enumBoolYesNo onCapturePointCaptured;
		public enumBoolYesNo onCapturePointLost;
		public enumBoolYesNo onEngineInit;
		public enumBoolYesNo onVeniceLevelLoaded;
		public enumBoolYesNo onPlayerReload;
		public enumBoolYesNo onAuthenticated;
		public enumBoolYesNo onChangingWeapon;
		public enumBoolYesNo onChat;
		public enumBoolYesNo onCreated;
		public enumBoolYesNo onDestroyed;
		public enumBoolYesNo onEnteredCapturePoint;
		public enumBoolYesNo onInstantSuicide;
		public enumBoolYesNo onJoining;
		public enumBoolYesNo onKickedFromSquad;
		public enumBoolYesNo onKilled;
		public enumBoolYesNo onKitPickup;
		public enumBoolYesNo onLeft;
		public enumBoolYesNo onRespawn;
		public enumBoolYesNo onResupply;
		public enumBoolYesNo onRevive;
		public enumBoolYesNo onReviveAccepted;
		public enumBoolYesNo onReviveRefused;
		public enumBoolYesNo onSetSquad;
		public enumBoolYesNo onSetSquadLeader;
		public enumBoolYesNo onSpawnAtVehicle;
		public enumBoolYesNo onSpawnOnPlayer;
		public enumBoolYesNo onSpawnOnSelectedSpawnPoint;
		public enumBoolYesNo onSquadChange;
		public enumBoolYesNo onSuppressedEnemy;
		public enumBoolYesNo onTeamChange;
		public enumBoolYesNo onUpdate;
		public enumBoolYesNo onUpdateInput;
		public enumBoolYesNo onRoundOver;
		public enumBoolYesNo onRoundReset;
		public enumBoolYesNo onHealthAction;
		public enumBoolYesNo onManDown;
		public enumBoolYesNo onPrePhysicsUpdate;
		public enumBoolYesNo onDamage;
		public enumBoolYesNo onVehicleDestroyed;
		public enumBoolYesNo onDisabled;
		public enumBoolYesNo onEnter;
		public enumBoolYesNo onExit;
		public enumBoolYesNo onSpawnDone;
		public enumBoolYesNo onUnspawn;
		public enumBoolYesNo onEntityFactoryCreate;
		public enumBoolYesNo onEntityFactoryCreateFromBlueprint;
		public enumBoolYesNo onFindBestSquad;
		public enumBoolYesNo onRequestJoin;
		public enumBoolYesNo onSelectTeam;
		public enumBoolYesNo onServerSuppressEnemies;
		public enumBoolYesNo onSoldierDamage;
		
        private bool m_isPluginEnabled;
		
		public CAdvancedRCON (){
			
			this.onCapturePointCaptured = enumBoolYesNo.No;
			this.onCapturePointLost = enumBoolYesNo.No;
			this.onEngineInit = enumBoolYesNo.No;
			this.onVeniceLevelLoaded = enumBoolYesNo.No;
			this.onPlayerReload = enumBoolYesNo.No;
			this.onAuthenticated = enumBoolYesNo.No;
			this.onChangingWeapon = enumBoolYesNo.No;
			this.onChat = enumBoolYesNo.No;
			this.onCreated = enumBoolYesNo.No;
			this.onDestroyed = enumBoolYesNo.No;
			this.onEnteredCapturePoint = enumBoolYesNo.No;
			this.onInstantSuicide = enumBoolYesNo.No;
			this.onJoining = enumBoolYesNo.No;
			this.onKickedFromSquad = enumBoolYesNo.No;
			this.onKilled = enumBoolYesNo.No;
			this.onKitPickup = enumBoolYesNo.No;
			this.onLeft = enumBoolYesNo.No;
			this.onRespawn = enumBoolYesNo.No;
			this.onResupply = enumBoolYesNo.No;
			this.onRevive = enumBoolYesNo.No;
			this.onReviveAccepted = enumBoolYesNo.No;
			this.onReviveRefused = enumBoolYesNo.No;
			this.onSetSquad = enumBoolYesNo.No;
			this.onSetSquadLeader = enumBoolYesNo.No;
			this.onSpawnAtVehicle = enumBoolYesNo.No;
			this.onSpawnOnPlayer = enumBoolYesNo.No;
			this.onSpawnOnSelectedSpawnPoint = enumBoolYesNo.No;
			this.onSquadChange = enumBoolYesNo.No;
			this.onSuppressedEnemy = enumBoolYesNo.No;
			this.onTeamChange = enumBoolYesNo.No;
			this.onUpdate = enumBoolYesNo.No;
			this.onUpdateInput = enumBoolYesNo.No;
			this.onRoundOver = enumBoolYesNo.No;
			this.onRoundReset = enumBoolYesNo.No;
			this.onHealthAction = enumBoolYesNo.No;
			this.onManDown = enumBoolYesNo.No;
			this.onPrePhysicsUpdate = enumBoolYesNo.No;
			this.onDamage = enumBoolYesNo.No;
			this.onVehicleDestroyed = enumBoolYesNo.No;
			this.onDisabled = enumBoolYesNo.No;
			this.onEnter = enumBoolYesNo.No;
			this.onExit = enumBoolYesNo.No;
			this.onSpawnDone = enumBoolYesNo.No;
			this.onUnspawn = enumBoolYesNo.No;
			this.onEntityFactoryCreate = enumBoolYesNo.No;
			this.onEntityFactoryCreateFromBlueprint = enumBoolYesNo.No;
			this.onFindBestSquad = enumBoolYesNo.No;
			this.onRequestJoin = enumBoolYesNo.No;
			this.onSelectTeam = enumBoolYesNo.No;
			this.onServerSuppressEnemies = enumBoolYesNo.No;
			this.onSoldierDamage = enumBoolYesNo.No;
			
            this.m_isPluginEnabled = false;
		}
		
		public string GetPluginName() {
            return "AdvancedRCON";
        }
		
		public string GetPluginVersion() {
            return "1.0";
        }
		
        public string GetPluginAuthor() {
            return "Flash_Hit";
        }
		
        public string GetPluginWebsite() {
            return "battlelog.battlefield.com/bf3/platoon/3307924585064219629/";
        }
		
		public string GetPluginDescription() {
            return @"
<h2>Description</h2>
    <p>Handles AdvancedRCON Events the easy way.</p>";
        }
		
        public void OnPluginLoaded(string strHostName, string strPort, string strPRoConVersion) {
		}
		
		public void OnPluginEnable() {
            this.ExecuteCommand("procon.protected.pluginconsole.write", "^bAdvancedRCON ^2Enabled!");

			
            this.m_isPluginEnabled = true;
        }

        public void OnPluginDisable() {
            this.ExecuteCommand("procon.protected.pluginconsole.write", "^bAdvancedRCON ^1Disabled!" );

            this.m_isPluginEnabled = false;
        }
		
		public List<CPluginVariable> GetDisplayPluginVariables() {

            List<CPluginVariable> lstReturn = new List<CPluginVariable>();
			lstReturn.Add(new CPluginVariable("OnCapturePointCaptured", typeof(enumBoolYesNo), this.onCapturePointCaptured));
			lstReturn.Add(new CPluginVariable("OnCapturePointLost", typeof(enumBoolYesNo), this.onCapturePointLost));
			lstReturn.Add(new CPluginVariable("OnEngineInit", typeof(enumBoolYesNo), this.onEngineInit));
			lstReturn.Add(new CPluginVariable("OnLevelLoaded", typeof(enumBoolYesNo), this.onVeniceLevelLoaded));
			lstReturn.Add(new CPluginVariable("OnPlayerAuthenticated", typeof(enumBoolYesNo), this.onAuthenticated));
			lstReturn.Add(new CPluginVariable("OnPlayerChangingWeapon", typeof(enumBoolYesNo), this.onChangingWeapon));
			lstReturn.Add(new CPluginVariable("OnPlayerChat", typeof(enumBoolYesNo), this.onChat));
			lstReturn.Add(new CPluginVariable("OnPlayerCreated", typeof(enumBoolYesNo), this.onCreated));
			lstReturn.Add(new CPluginVariable("OnPlayerDestroyed", typeof(enumBoolYesNo), this.onDestroyed));
			lstReturn.Add(new CPluginVariable("OnPlayerEnteredCapturePoint", typeof(enumBoolYesNo), this.onEnteredCapturePoint));
			lstReturn.Add(new CPluginVariable("OnPlayerInstantSuicide", typeof(enumBoolYesNo), this.onInstantSuicide));
			lstReturn.Add(new CPluginVariable("OnPlayerJoining", typeof(enumBoolYesNo), this.onJoining));
			lstReturn.Add(new CPluginVariable("OnPlayerKickedFromSquad", typeof(enumBoolYesNo), this.onKickedFromSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerKilled", typeof(enumBoolYesNo), this.onKilled));
			lstReturn.Add(new CPluginVariable("OnPlayerKitPickup", typeof(enumBoolYesNo), this.onKitPickup));
			lstReturn.Add(new CPluginVariable("OnPlayerLeft", typeof(enumBoolYesNo), this.onLeft));
			lstReturn.Add(new CPluginVariable("OnPlayerReload", typeof(enumBoolYesNo), this.onPlayerReload));
			lstReturn.Add(new CPluginVariable("OnPlayerRespawn", typeof(enumBoolYesNo), this.onRespawn));
			lstReturn.Add(new CPluginVariable("OnPlayerResupply", typeof(enumBoolYesNo), this.onResupply));
			lstReturn.Add(new CPluginVariable("OnPlayerRevive", typeof(enumBoolYesNo), this.onRevive));
			lstReturn.Add(new CPluginVariable("OnPlayerReviveAccepted", typeof(enumBoolYesNo), this.onReviveAccepted));
			lstReturn.Add(new CPluginVariable("OnPlayerReviveRefused", typeof(enumBoolYesNo), this.onReviveRefused));
			lstReturn.Add(new CPluginVariable("OnPlayerSetSquad", typeof(enumBoolYesNo), this.onSetSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerSetSquadLeader", typeof(enumBoolYesNo), this.onSetSquadLeader));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnAtVehicle", typeof(enumBoolYesNo), this.onSpawnAtVehicle));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnOnPlayer", typeof(enumBoolYesNo), this.onSpawnOnPlayer));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnOnSelectedSpawnPoint", typeof(enumBoolYesNo), this.onSpawnOnSelectedSpawnPoint));
			lstReturn.Add(new CPluginVariable("OnPlayerSquadChange", typeof(enumBoolYesNo), this.onSquadChange));
			lstReturn.Add(new CPluginVariable("OnPlayerSuppressedEnemy", typeof(enumBoolYesNo), this.onSuppressedEnemy));
			lstReturn.Add(new CPluginVariable("OnPlayerTeamChange", typeof(enumBoolYesNo), this.onTeamChange));
			lstReturn.Add(new CPluginVariable("OnPlayerUpdate", typeof(enumBoolYesNo), this.onUpdate));
			lstReturn.Add(new CPluginVariable("OnPlayerUpdateInput", typeof(enumBoolYesNo), this.onUpdateInput));
			lstReturn.Add(new CPluginVariable("OnServerRoundOver", typeof(enumBoolYesNo), this.onRoundOver));
			lstReturn.Add(new CPluginVariable("OnServerRoundReset", typeof(enumBoolYesNo), this.onRoundReset));
			lstReturn.Add(new CPluginVariable("OnSoldierHealthAction", typeof(enumBoolYesNo), this.onHealthAction));
			lstReturn.Add(new CPluginVariable("OnSoldierManDown", typeof(enumBoolYesNo), this.onManDown));
			lstReturn.Add(new CPluginVariable("OnSoldierPrePhysicsUpdate", typeof(enumBoolYesNo), this.onPrePhysicsUpdate));
			lstReturn.Add(new CPluginVariable("OnVehicleDamage", typeof(enumBoolYesNo), this.onDamage));
			lstReturn.Add(new CPluginVariable("OnVehicleDestroyed", typeof(enumBoolYesNo), this.onVehicleDestroyed));
			lstReturn.Add(new CPluginVariable("OnVehicleDisabled", typeof(enumBoolYesNo), this.onDisabled));
			lstReturn.Add(new CPluginVariable("OnVehicleEnter", typeof(enumBoolYesNo), this.onEnter));
			lstReturn.Add(new CPluginVariable("OnVehicleExit", typeof(enumBoolYesNo), this.onExit));
			lstReturn.Add(new CPluginVariable("OnVehicleSpawnDone", typeof(enumBoolYesNo), this.onSpawnDone));
			lstReturn.Add(new CPluginVariable("OnVehicleUnspawn", typeof(enumBoolYesNo), this.onUnspawn));
			lstReturn.Add(new CPluginVariable("OnEntityFactoryCreate", typeof(enumBoolYesNo), this.onEntityFactoryCreate));
			lstReturn.Add(new CPluginVariable("OnEntityFactoryCreateFromBlueprint", typeof(enumBoolYesNo), this.onEntityFactoryCreateFromBlueprint));
			lstReturn.Add(new CPluginVariable("OnPlayerFindBestSquad", typeof(enumBoolYesNo), this.onFindBestSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerRequestJoin", typeof(enumBoolYesNo), this.onRequestJoin));
			lstReturn.Add(new CPluginVariable("OnPlayerSelectTeam", typeof(enumBoolYesNo), this.onSelectTeam));
			lstReturn.Add(new CPluginVariable("OnServerSuppressEnemies", typeof(enumBoolYesNo), this.onServerSuppressEnemies));
			lstReturn.Add(new CPluginVariable("OnSoldierDamage", typeof(enumBoolYesNo), this.onSoldierDamage));
			
            return lstReturn;
        }

        public List<CPluginVariable> GetPluginVariables() {
			
            List<CPluginVariable> lstReturn = new List<CPluginVariable>();
			lstReturn.Add(new CPluginVariable("OnCapturePointCaptured", typeof(enumBoolYesNo), this.onCapturePointCaptured));
			lstReturn.Add(new CPluginVariable("OnCapturePointLost", typeof(enumBoolYesNo), this.onCapturePointLost));
			lstReturn.Add(new CPluginVariable("OnEngineInit", typeof(enumBoolYesNo), this.onEngineInit));
			lstReturn.Add(new CPluginVariable("OnLevelLoaded", typeof(enumBoolYesNo), this.onVeniceLevelLoaded));
			lstReturn.Add(new CPluginVariable("OnPlayerAuthenticated", typeof(enumBoolYesNo), this.onAuthenticated));
			lstReturn.Add(new CPluginVariable("OnPlayerChangingWeapon", typeof(enumBoolYesNo), this.onChangingWeapon));
			lstReturn.Add(new CPluginVariable("OnPlayerChat", typeof(enumBoolYesNo), this.onChat));
			lstReturn.Add(new CPluginVariable("OnPlayerCreated", typeof(enumBoolYesNo), this.onCreated));
			lstReturn.Add(new CPluginVariable("OnPlayerDestroyed", typeof(enumBoolYesNo), this.onDestroyed));
			lstReturn.Add(new CPluginVariable("OnPlayerEnteredCapturePoint", typeof(enumBoolYesNo), this.onEnteredCapturePoint));
			lstReturn.Add(new CPluginVariable("OnPlayerInstantSuicide", typeof(enumBoolYesNo), this.onInstantSuicide));
			lstReturn.Add(new CPluginVariable("OnPlayerJoining", typeof(enumBoolYesNo), this.onJoining));
			lstReturn.Add(new CPluginVariable("OnPlayerKickedFromSquad", typeof(enumBoolYesNo), this.onKickedFromSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerKilled", typeof(enumBoolYesNo), this.onKilled));
			lstReturn.Add(new CPluginVariable("OnPlayerKitPickup", typeof(enumBoolYesNo), this.onKitPickup));
			lstReturn.Add(new CPluginVariable("OnPlayerLeft", typeof(enumBoolYesNo), this.onLeft));
			lstReturn.Add(new CPluginVariable("OnPlayerReload", typeof(enumBoolYesNo), this.onPlayerReload));
			lstReturn.Add(new CPluginVariable("OnPlayerRespawn", typeof(enumBoolYesNo), this.onRespawn));
			lstReturn.Add(new CPluginVariable("OnPlayerResupply", typeof(enumBoolYesNo), this.onResupply));
			lstReturn.Add(new CPluginVariable("OnPlayerRevive", typeof(enumBoolYesNo), this.onRevive));
			lstReturn.Add(new CPluginVariable("OnPlayerReviveAccepted", typeof(enumBoolYesNo), this.onReviveAccepted));
			lstReturn.Add(new CPluginVariable("OnPlayerReviveRefused", typeof(enumBoolYesNo), this.onReviveRefused));
			lstReturn.Add(new CPluginVariable("OnPlayerSetSquad", typeof(enumBoolYesNo), this.onSetSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerSetSquadLeader", typeof(enumBoolYesNo), this.onSetSquadLeader));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnAtVehicle", typeof(enumBoolYesNo), this.onSpawnAtVehicle));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnOnPlayer", typeof(enumBoolYesNo), this.onSpawnOnPlayer));
			lstReturn.Add(new CPluginVariable("OnPlayerSpawnOnSelectedSpawnPoint", typeof(enumBoolYesNo), this.onSpawnOnSelectedSpawnPoint));
			lstReturn.Add(new CPluginVariable("OnPlayerSquadChange", typeof(enumBoolYesNo), this.onSquadChange));
			lstReturn.Add(new CPluginVariable("OnPlayerSuppressedEnemy", typeof(enumBoolYesNo), this.onSuppressedEnemy));
			lstReturn.Add(new CPluginVariable("OnPlayerTeamChange", typeof(enumBoolYesNo), this.onTeamChange));
			lstReturn.Add(new CPluginVariable("OnPlayerUpdate", typeof(enumBoolYesNo), this.onUpdate));
			lstReturn.Add(new CPluginVariable("OnPlayerUpdateInput", typeof(enumBoolYesNo), this.onUpdateInput));
			lstReturn.Add(new CPluginVariable("OnServerRoundOver", typeof(enumBoolYesNo), this.onRoundOver));
			lstReturn.Add(new CPluginVariable("OnServerRoundReset", typeof(enumBoolYesNo), this.onRoundReset));
			lstReturn.Add(new CPluginVariable("OnSoldierHealthAction", typeof(enumBoolYesNo), this.onHealthAction));
			lstReturn.Add(new CPluginVariable("OnSoldierManDown", typeof(enumBoolYesNo), this.onManDown));
			lstReturn.Add(new CPluginVariable("OnSoldierPrePhysicsUpdate", typeof(enumBoolYesNo), this.onPrePhysicsUpdate));
			lstReturn.Add(new CPluginVariable("OnVehicleDamage", typeof(enumBoolYesNo), this.onDamage));
			lstReturn.Add(new CPluginVariable("OnVehicleDestroyed", typeof(enumBoolYesNo), this.onVehicleDestroyed));
			lstReturn.Add(new CPluginVariable("OnVehicleDisabled", typeof(enumBoolYesNo), this.onDisabled));
			lstReturn.Add(new CPluginVariable("OnVehicleEnter", typeof(enumBoolYesNo), this.onEnter));
			lstReturn.Add(new CPluginVariable("OnVehicleExit", typeof(enumBoolYesNo), this.onExit));
			lstReturn.Add(new CPluginVariable("OnVehicleSpawnDone", typeof(enumBoolYesNo), this.onSpawnDone));
			lstReturn.Add(new CPluginVariable("OnVehicleUnspawn", typeof(enumBoolYesNo), this.onUnspawn));
			lstReturn.Add(new CPluginVariable("OnEntityFactoryCreate", typeof(enumBoolYesNo), this.onEntityFactoryCreate));
			lstReturn.Add(new CPluginVariable("OnEntityFactoryCreateFromBlueprint", typeof(enumBoolYesNo), this.onEntityFactoryCreateFromBlueprint));
			lstReturn.Add(new CPluginVariable("OnPlayerFindBestSquad", typeof(enumBoolYesNo), this.onFindBestSquad));
			lstReturn.Add(new CPluginVariable("OnPlayerRequestJoin", typeof(enumBoolYesNo), this.onRequestJoin));
			lstReturn.Add(new CPluginVariable("OnPlayerSelectTeam", typeof(enumBoolYesNo), this.onSelectTeam));
			lstReturn.Add(new CPluginVariable("OnServerSuppressEnemies", typeof(enumBoolYesNo), this.onServerSuppressEnemies));
			lstReturn.Add(new CPluginVariable("OnSoldierDamage", typeof(enumBoolYesNo), this.onSoldierDamage));
			
            return GetDisplayPluginVariables();
        }
		
		public void SetPluginVariable(string strVariable, string strValue) {
			if (m_isPluginEnabled == true) {
				if (strVariable.CompareTo("OnCapturePointCaptured") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onCapturePointCaptured = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onCapturePointCaptured.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCapture", "true");
					}
					else if (this.onCapturePointCaptured.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCapture", "false");
					}
				}
				else if (strVariable.CompareTo("OnCapturePointLost") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onCapturePointLost = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onCapturePointLost.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCapturePointLost", "true");
					}
					else if (this.onCapturePointLost.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCapturePointLost", "false");
					}
				}
				else if (strVariable.CompareTo("OnEngineInit") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onEngineInit = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onEngineInit.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEngineInit", "true");
					}
					else if (this.onEngineInit.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEngineInit", "false");
					}
				}
				else if (strVariable.CompareTo("OnLevelLoaded") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onVeniceLevelLoaded = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onVeniceLevelLoaded.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onLevelLoaded", "true");
					}
					else if (this.onVeniceLevelLoaded.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onLevelLoaded", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerReload") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onPlayerReload = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onPlayerReload.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReload", "true");
					}
					else if (this.onPlayerReload.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReload", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerAuthenticated") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onAuthenticated = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onAuthenticated.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onAuthenticated", "true");
					}
					else if (this.onAuthenticated.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onAuthenticated", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerChangingWeapon") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onChangingWeapon = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onChangingWeapon.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onChangingWeapon", "true");
					}
					else if (this.onChangingWeapon.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onChangingWeapon", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerChat") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onChat = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onChat.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onChat", "true");
					}
					else if (this.onChat.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onChat", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerCreated") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onCreated = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onCreated.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCreated", "true");
					}
					else if (this.onCreated.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onCreated", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerDestroyed") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onDestroyed = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onDestroyed.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDestroyed", "true");
					}
					else if (this.onDestroyed.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDestroyed", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerEnteredCapturePoint") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onEnteredCapturePoint = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onEnteredCapturePoint.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEnteredCapturePoint", "true");
					}
					else if (this.onEnteredCapturePoint.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEnteredCapturePoint", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerInstantSuicide") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onInstantSuicide = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onInstantSuicide.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onInstantSuicide", "true");
					}
					else if (this.onInstantSuicide.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onInstantSuicide", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerJoining") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onJoining = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onJoining.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onJoining", "true");
					}
					else if (this.onJoining.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onJoining", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerAuthenticated") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onAuthenticated = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onAuthenticated.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onAuthenticated", "true");
					}
					else if (this.onAuthenticated.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onAuthenticated", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerKickedFromSquad") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onKickedFromSquad = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onKickedFromSquad.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKickedFromSquad", "true");
					}
					else if (this.onKickedFromSquad.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKickedFromSquad", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerKilled") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onKilled = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onKilled.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKilled", "true");
					}
					else if (this.onKilled.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKilled", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerKitPickup") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onKitPickup = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onKitPickup.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKitPickup", "true");
					}
					else if (this.onKitPickup.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onKitPickup", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerLeft") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onLeft = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onLeft.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onLeft", "true");
					}
					else if (this.onLeft.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onLeft", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerRespawn") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onRespawn = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onRespawn.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRespawn", "true");
					}
					else if (this.onRespawn.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRespawn", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerResupply") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onResupply = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onResupply.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onResupply", "true");
					}
					else if (this.onResupply.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onResupply", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerRevive") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onRevive = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onRevive.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRevive", "true");
					}
					else if (this.onReviveAccepted.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRevive", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerReviveAccepted") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onReviveAccepted = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onReviveAccepted.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReviveAccepted", "true");
					}
					else if (this.onReviveAccepted.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReviveAccepted", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerReviveRefused") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onReviveRefused = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onReviveRefused.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReviveRefused", "true");
					}
					else if (this.onReviveRefused.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onReviveRefused", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSetSquad") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSetSquad = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSetSquad.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSetSquad", "true");
					}
					else if (this.onSetSquad.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSetSquad", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSetSquadLeader") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSetSquadLeader = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSetSquadLeader.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSetSquadLeader", "true");
					}
					else if (this.onSetSquadLeader.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSetSquadLeader", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSpawnAtVehicle") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSpawnAtVehicle = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSpawnAtVehicle.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnAtVehicle", "true");
					}
					else if (this.onSpawnAtVehicle.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnAtVehicle", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSpawnOnPlayer") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSpawnOnPlayer = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSpawnOnPlayer.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnOnPlayer", "true");
					}
					else if (this.onSpawnOnPlayer.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnOnPlayer", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSpawnOnSelectedSpawnPoint") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSpawnOnSelectedSpawnPoint = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSpawnOnSelectedSpawnPoint.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnOnSelectedSpawnPoint", "true");
					}
					else if (this.onSpawnOnSelectedSpawnPoint.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnOnSelectedSpawnPoint", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSquadChange") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSquadChange = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSquadChange.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSquadChange", "true");
					}
					else if (this.onSquadChange.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSquadChange", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSuppressedEnemy") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSuppressedEnemy = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSuppressedEnemy.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSuppressedEnemy", "true");
					}
					else if (this.onSuppressedEnemy.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSuppressedEnemy", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerTeamChange") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onTeamChange = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onTeamChange.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onTeamChange", "true");
					}
					else if (this.onTeamChange.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onTeamChange", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerUpdate") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onUpdate = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onUpdate.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUpdate", "true");
					}
					else if (this.onUpdate.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUpdate", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerUpdateInput") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onUpdateInput = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onUpdateInput.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUpdateInput", "true");
					}
					else if (this.onUpdateInput.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUpdateInput", "false");
					}
				}
				else if (strVariable.CompareTo("OnServerRoundOver") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onRoundOver = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onRoundOver.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRoundOver", "true");
					}
					else if (this.onRoundOver.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRoundOver", "false");
					}
				}
				else if (strVariable.CompareTo("OnServerRoundReset") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onRoundReset = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onRoundReset.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRoundReset", "true");
					}
					else if (this.onRoundReset.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRoundReset", "false");
					}
				}
				else if (strVariable.CompareTo("OnSoldierHealthAction") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onHealthAction = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onHealthAction.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onHealthAction", "true");
					}
					else if (this.onHealthAction.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onHealthAction", "false");
					}
				}
				else if (strVariable.CompareTo("OnSoldierManDown") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onManDown = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onManDown.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onManDown", "true");
					}
					else if (this.onManDown.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onManDown", "false");
					}
				}
				else if (strVariable.CompareTo("OnSoldierPrePhysicsUpdate") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onPrePhysicsUpdate = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onPrePhysicsUpdate.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onPrePhysicsUpdate", "true");
					}
					else if (this.onPrePhysicsUpdate.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onPrePhysicsUpdate", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleDamage") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onDamage = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onDamage.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDamage", "true");
					}
					else if (this.onDamage.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDamage", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleDestroyed") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onVehicleDestroyed = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onVehicleDestroyed.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onVehicleDestroyed", "true");
					}
					else if (this.onVehicleDestroyed.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onVehicleDestroyed", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleDisabled") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onDisabled = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onDisabled.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDisabled", "true");
					}
					else if (this.onDisabled.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onDisabled", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleEnter") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onEnter = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onEnter.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEnter", "true");
					}
					else if (this.onEnter.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEnter", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleExit") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onExit = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onExit.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onExit", "true");
					}
					else if (this.onExit.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onExit", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleSpawnDone") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSpawnDone = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSpawnDone.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnDone", "true");
					}
					else if (this.onSpawnDone.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSpawnDone", "false");
					}
				}
				else if (strVariable.CompareTo("OnVehicleUnspawn") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onUnspawn = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onUnspawn.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUnspawn", "true");
					}
					else if (this.onUnspawn.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onUnspawn", "false");
					}
				}
				else if (strVariable.CompareTo("OnEntityFactoryCreate") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onEntityFactoryCreate = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onEntityFactoryCreate.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEntityFactoryCreate", "true");
					}
					else if (this.onEntityFactoryCreate.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEntityFactoryCreate", "false");
					}
				}
				else if (strVariable.CompareTo("OnEntityFactoryCreateFromBlueprint") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onEntityFactoryCreateFromBlueprint = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onEntityFactoryCreateFromBlueprint.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEntityFactoryCreateFromBlueprint", "true");
					}
					else if (this.onEntityFactoryCreateFromBlueprint.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onEntityFactoryCreateFromBlueprint", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerFindBestSquad") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onFindBestSquad = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onFindBestSquad.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onFindBestSquad", "true");
					}
					else if (this.onFindBestSquad.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onFindBestSquad", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerRequestJoin") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onRequestJoin = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onRequestJoin.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRequestJoin", "true");
					}
					else if (this.onRequestJoin.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onRequestJoin", "false");
					}
				}
				else if (strVariable.CompareTo("OnPlayerSelectTeam") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSelectTeam = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSelectTeam.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSelectTeam", "true");
					}
					else if (this.onSelectTeam.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSelectTeam", "false");
					}
				}
				else if (strVariable.CompareTo("OnServerSuppressEnemies") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onServerSuppressEnemies = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onServerSuppressEnemies.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onServerSuppressEnemies", "true");
					}
					else if (this.onServerSuppressEnemies.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onServerSuppressEnemies", "false");
					}
				}
				else if (strVariable.CompareTo("OnSoldierDamage") == 0 && Enum.IsDefined(typeof(enumBoolYesNo), strValue) == true) {
					this.onSoldierDamage = (enumBoolYesNo)Enum.Parse(typeof(enumBoolYesNo), strValue);
					if (this.onSoldierDamage.ToString() == "Yes") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSoldierDamage", "true");
					}
					else if (this.onSoldierDamage.ToString() == "No") {
						this.ExecuteCommand("procon.protected.send", "vu.Event", "onSoldierDamage", "false");
					}
				}
			}
        }
	}
}