using System;
using System.IO;
using System.Text;
using System.Reflection;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading;
using System.Timers;

using PRoCon.Core;
using PRoCon.Core.Plugin;
using PRoCon.Core.Plugin.Commands;
using PRoCon.Core.Players;
using PRoCon.Core.Players.Items;
using PRoCon.Core.TextChatModeration;
using PRoCon.Core.Battlemap;
using PRoCon.Core.Maps;
using PRoCon.Core.HttpServer;

namespace PRoConEvents {
	
	public class CTextChatModerationManager : PRoConPluginAPI, IPRoConPluginInterface {
		public enum ChatModerationMode{
			Free,
			Moderated,
			Muted
		}
		private ChatModerationMode chatModerationMode = ChatModerationMode.Free;
		static List<string> textChatModerationList = new List<string>();
		private int textChatSpamTriggerCount;
		private int textChatSpamCoolDownTime;
		private int textChatSpamDetectionTime;
		private bool onReload;
        private bool m_isPluginEnabled;
		
		public CTextChatModerationManager (){
			textChatModerationList.Add("admin:Flash_Hit");
			textChatModerationList.Add("voice:voteban_flash");
			textChatModerationList.Add("muted:RazorRamon");
			this.onReload = true;
			this.textChatSpamTriggerCount = 6;
			this.textChatSpamCoolDownTime = 30;
			this.textChatSpamDetectionTime = 6;
            this.m_isPluginEnabled = false;
		}
		
		public string GetPluginName() {
            return "TextChatModeration";
        }
		
		public string GetPluginVersion() {
            return "1.0";
        }
		
        public string GetPluginAuthor() {
            return "Flash_Hit";
        }
		
        public string GetPluginWebsite() {
            return "battlelog.battlefield.com/bf3/platoon/3307924585064219629/";
        }
		
		public string GetPluginDescription() {
            return @"
<h2>Description</h2>
    <p>Set up the TextChatModeration with this mod.</p>";
        }
		
		public void OnPluginLoaded(string strHostName, string strPort, string strPRoConVersion) {
			
			this.RegisterEvents(this.GetType().Name, "OnTextChatModerationLoad", "OnTextChatModerationList", "OnTextChatModerationClear", "OnTextChatModerationRemovePlayer", "OnTextChatModerationAddPlayer");
        }
		
		public void OnPluginEnable() {
            this.ExecuteCommand("procon.protected.pluginconsole.write", "^bTextChatModerationManager ^2Enabled!");
			foreach (string data in textChatModerationList) {
				string[] parts = data.Split(':');
				this.ExecuteCommand("procon.protected.send", "textChatModerationList.addPlayer", parts[0], parts[1]);
			}
            this.m_isPluginEnabled = true;
        }

        public void OnPluginDisable() {
            this.ExecuteCommand("procon.protected.pluginconsole.write", "^bTextChatModerationManager ^1Disabled!" );

            this.m_isPluginEnabled = false;
        }
		
		public List<CPluginVariable> GetDisplayPluginVariables() {

            List<CPluginVariable> lstReturn = new List<CPluginVariable>();
			lstReturn.Add(new CPluginVariable("TextChatModerationMode", CreateEnumString(typeof(ChatModerationMode)), chatModerationMode.ToString()));
			lstReturn.Add(new CPluginVariable("TextChatSpamTriggerCount", typeof(int), textChatSpamTriggerCount));
			lstReturn.Add(new CPluginVariable("TextChatSpamCoolDownTime", typeof(int), textChatSpamCoolDownTime));
			lstReturn.Add(new CPluginVariable("TextChatSpamDetectionTime", typeof(int), textChatSpamDetectionTime));
			lstReturn.Add(new CPluginVariable("TextChatModerationList", typeof(string[]), textChatModerationList.ToArray()));
			
            return lstReturn;
        }

        public List<CPluginVariable> GetPluginVariables() {
			
            List<CPluginVariable> lstReturn = new List<CPluginVariable>();
			lstReturn.Add(new CPluginVariable("TextChatModerationMode", CreateEnumString(typeof(ChatModerationMode)), chatModerationMode.ToString()));
			lstReturn.Add(new CPluginVariable("TextChatSpamTriggerCount", typeof(int), textChatSpamTriggerCount));
			lstReturn.Add(new CPluginVariable("TextChatSpamCoolDownTime", typeof(int), textChatSpamCoolDownTime));
			lstReturn.Add(new CPluginVariable("TextChatSpamDetectionTime", typeof(int), textChatSpamDetectionTime));
			lstReturn.Add(new CPluginVariable("TextChatModerationList", typeof(string[]), textChatModerationList.ToArray()));
			
            return GetDisplayPluginVariables();
        }
		
		public void SetPluginVariable(string strVariable, string strValue) {
			if (strVariable.CompareTo("TextChatModerationList") == 0) {
				this.ExecuteCommand("procon.protected.send", "textChatModerationList.clear");
                textChatModerationList = new List<string>(CPluginVariable.DecodeStringArray(strValue));
				foreach (string data in textChatModerationList) {
					string[] parts = data.Split(':');
					this.ExecuteCommand("procon.protected.send", "textChatModerationList.addPlayer", parts[0], parts[1]);
				}
			}
			else if (Regex.Match(strVariable, @"TextChatModerationMode").Success) {
		  		this.chatModerationMode = (ChatModerationMode)Enum.Parse(typeof(ChatModerationMode), strValue);
				if(chatModerationMode.ToString() == "Free")
				{
					this.ExecuteCommand("procon.protected.send", "vars.textChatModerationMode", "free");
				}
				else if(chatModerationMode.ToString() == "Moderated")
				{
					this.ExecuteCommand("procon.protected.send", "vars.textChatModerationMode", "moderated");
				}
				else if(chatModerationMode.ToString() == "Muted")
				{
					this.ExecuteCommand("procon.protected.send", "vars.textChatModerationMode", "muted");
				}
            }
			else if (Regex.Match(strVariable, @"TextChatSpamTriggerCount").Success)
            {
                int tmpTextChatSpamTriggerCount = 6;
                int.TryParse(strValue, out tmpTextChatSpamTriggerCount);
                textChatSpamTriggerCount = tmpTextChatSpamTriggerCount;
				this.ExecuteCommand("procon.protected.send", "vars.textChatSpamTriggerCount", textChatSpamTriggerCount.ToString());
            } 
			else if (Regex.Match(strVariable, @"TextChatSpamCoolDownTime").Success)
            {
                int tmpTextChatSpamCoolDownTime = 30;
                int.TryParse(strValue, out tmpTextChatSpamCoolDownTime);
                textChatSpamCoolDownTime = tmpTextChatSpamCoolDownTime;
				this.ExecuteCommand("procon.protected.send", "vars.textChatSpamCoolDownTime", textChatSpamCoolDownTime.ToString());
            }
			else if (Regex.Match(strVariable, @"TextChatSpamDetectionTime").Success)
            {
                int tmpTextChatSpamDetectionTime = 6;
                int.TryParse(strValue, out tmpTextChatSpamDetectionTime);
                textChatSpamDetectionTime = tmpTextChatSpamDetectionTime;
				this.ExecuteCommand("procon.protected.send", "vars.textChatSpamDetectionTime", textChatSpamDetectionTime.ToString());
            } 
        }
		public void OnTextChatModerationLoad() { 
			this.ExecuteCommand("procon.protected.send", "textChatModerationList.list");
		}
		public void OnTextChatModerationAddPlayer(TextChatModerationEntry playerEntry) { 
			bool playerfound = false;
			string toinsert = playerEntry.PlayerModerationLevel.ToString().ToLower()+":"+playerEntry.SoldierName;
			string muted = "muted:"+playerEntry.SoldierName;
			string voice = "voice:"+playerEntry.SoldierName;
			string admin = "admin:"+playerEntry.SoldierName;
			int x = 0;
			foreach (string player in textChatModerationList) {
				if (player == muted || player == voice || player == admin) {
					playerfound = true;
					textChatModerationList[x] = toinsert;
				}
				x++;
			}
			if (playerfound == false) {
				textChatModerationList.Add(toinsert);
			}
		}
        public void OnTextChatModerationRemovePlayer(TextChatModerationEntry playerEntry) { 
			string muted = "muted:"+playerEntry.SoldierName;
			string voice = "voice:"+playerEntry.SoldierName;
			string admin = "admin:"+playerEntry.SoldierName;
			foreach (string player in textChatModerationList) {
				if (player == muted) {
					textChatModerationList.Remove(muted);
				}
				else if (player == voice) {
					textChatModerationList.Remove(voice);
				}
				else if (player == admin) {
					textChatModerationList.Remove(admin);
				}
			}
		}
        public void OnTextChatModerationClear() { 
			if (onReload == false) {
				textChatModerationList.Clear();
			}else{
				onReload = false;
			}
		}
        public void OnTextChatModerationList(TextChatModerationDictionary moderationList) { 	
			textChatModerationList.Clear();
			foreach(var item in moderationList)
			{
				textChatModerationList.Add(item.PlayerModerationLevel.ToString().ToLower()+":"+item.SoldierName);
			}
		}
	}
}